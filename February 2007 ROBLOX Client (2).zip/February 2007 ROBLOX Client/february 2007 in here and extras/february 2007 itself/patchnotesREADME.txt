
This ROBLOX build was compiled on February 2007. 
Some of these patch files are from ORRH [as the client before was half broken so i had to patch it somehow]
This was patched by redblueofficer. Check out his YouTube channel and ROBLOX account.

Some files may say ''Made in June 2021'', but that is because this app was patched with some ORRH files and some of them were from 2021, some pieces in the app too.
Some features may be missing.

At the time of patching this client, this is the OLDEST CLIENT FOUND of ROBLOX.
Thank you for reading this.